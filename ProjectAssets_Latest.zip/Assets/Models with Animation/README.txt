README document for MODELS WITH ANIMATIONS directory.

Need to create:


	- Animation Skeleton for PHOENIX BOSS. (.blend file)

*****************************************************************
BELOW ARE ANIMATIONS, BASED ON FILES INCLUDED IN THE ABOVE DIRECTORY


Character_Global

	- Movement 1-hand weapon

	- Movement 2-hand weapon

	- Mining

	- Gathering

	- 1-handed weapon basic attack 1

	- 1-handed weapon basic attack 2

	- 1-handed weapon basic attack 3

	- Death

	- Respawn (optional)


Character_Mage

	- Basic spell cast (Projectile)

	- Focussed / Heavy spell cast (Projectile)


Charcter_Rogue

	- Bow aim / shoot (short bow only)


Character_Warrior

	- 1-handed weapon heavy attack

	- 2-handed weapon basic attack 1 (non-spear only)

	- 2-handed weapon basic attack 2 (non-spear only)

	- 2-handed weapon heavy attack	 (non-spear only)


Mobs

	- Zombie H2H melee attack

	- Zombie movement

	- Cultist boss death


Phoenix

	- Movement

	- Basic attack

	- Charging power

	- Power attack

	- Birth

	- Death