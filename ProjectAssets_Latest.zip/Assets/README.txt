README file for ASSETS directory

Breakdown of files

Models
************

Contains all non-rigged models (static scenery / character meshes etc.)


Models with Animation
***************************

Contains animations with a dummy character (initially).
README file lists each different animation ONCE (not each instance, i.e movement of mobs is identical to character, but not mentioned).


Pictures
**************

Contains assets for menus (buttons / logo / backgrounds / etc.)


Textures
**************

Contains all textures for all objects.